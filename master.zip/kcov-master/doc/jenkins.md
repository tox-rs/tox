Integration with Jenkins
------------------------
Kcov also outputs data in the Cobertura XML format, which allows integrating kcov
output in Jenkins (see http://cobertura.sf.net and http://jenkins-ci.org).

The Cobertura output is placed in a file named ```out-path/exec-filename/cobertura.xml```
