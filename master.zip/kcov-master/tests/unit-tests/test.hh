#pragma once

#include "trompeloeil.hpp"
#include <crpcut.hpp>

using trompeloeil::_;
