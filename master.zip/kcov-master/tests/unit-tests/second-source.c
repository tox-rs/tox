int mibb(int a)
{
	// "Hej" and 'hej' means HTML escaping! \ is another escape
	if (a < 5 && a > 3)
		return 0;

	return a - 1;
}
