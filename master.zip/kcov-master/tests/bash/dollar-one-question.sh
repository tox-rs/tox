#!/bin/bash
#echo before
fparam=${1:?}
echo $fparam
