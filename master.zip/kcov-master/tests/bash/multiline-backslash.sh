#!/bin/bash
USAGE="usage: ${toolName} [--help] [--option1] \\
       [--option1|--option3] \\
       function_name [function_options] ...
"
