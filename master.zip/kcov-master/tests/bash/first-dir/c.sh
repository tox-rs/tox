#!/bin/sh

echo C now

