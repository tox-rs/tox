#include <stdio.h>
#include "../include/header.h"

void tjoho(int a)
{
	if (a)
		printf("Hej\n");
}
