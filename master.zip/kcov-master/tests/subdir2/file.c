#include <stdio.h>
#include "../include/header.h"

void tjoho2(int a)
{
	if (a)
		printf("Hej\n");
}
