#!/bin/sh

# Turn on tracing
set -x
